function enviaSete(){
    document.getElementById("visor").value += "7"
}
function enviaOito(){
    document.getElementById("visor").value += "8"
}
function enviaNove(){
    document.getElementById("visor").value += "9"
}

function enviaQuatro(){
    document.getElementById("visor").value += "4"
}

function enviaCinco(){
    document.getElementById("visor").value += "5"
}

function enviaSeis(){
    document.getElementById("visor").value += "6"
}

function enviaUm(){
    document.getElementById("visor").value += "1"
}

function enviaDois(){
    document.getElementById("visor").value += "2"
}

function enviaTres(){
    document.getElementById("visor").value += "3"
}

function enviaZero(){
    document.getElementById("visor").value += "0"
}

