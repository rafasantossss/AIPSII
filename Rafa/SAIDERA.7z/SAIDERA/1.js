let nota1, nota2, média

nota1 = Number(prompt("Qual a primeira nota?"))
nota2 = Number(prompt("Qual a segunda nota?"))

média = (nota1+nota2)/2

if(média >= 7){
    alert("nota: "+média+"=Aprovado")
}else{
    alert("nota: "+média+"=Desaprovado")
}