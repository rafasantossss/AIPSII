let dias

dias = Number(prompt("Quantos diárias:"))

if(dias <= 5)
{
    alert(((dias*100)+150)*0.25)
}   

if(dias >5 && dias <= 10)
{
    alert(((dias*90)+150)+(((dias*90)+150)*0.25))
}   

if(dias >10)
{
    alert(((dias*80)+150)+(((dias*90)+150)*0.25))
}   
