let pontos

pontos = Number(prompt("Qual a pontuação"))

if(pontos <= 10){
    alert("bah, ta mal")
}

if(pontos > 10 && pontos <= 100){
    alert("Supimpa")
}   

if(pontos > 100 && pontos < 200){
    alert("mitou")
}

if(pontos >=200){
alert("boa")
}