let halls, cafe, coxinha, doceDeleite

halls = Number(prompt("Preço da halls"))

cafe = Number(prompt("Preço do cafe"))

coxinha = Number(prompt("Preço da coxinha"))

doceDeleite = Number(prompt("Preço do doce de leite"))

alert((halls*2)+cafe+coxinha+doceDeleite)