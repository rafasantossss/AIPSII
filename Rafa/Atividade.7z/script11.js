let cafe, alunos

cafe = parseInt(prompt("cafe"))
alunos = parseInt(prompt("alunos"))

alert(cafe/alunos)