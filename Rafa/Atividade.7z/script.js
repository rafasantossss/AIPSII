let salario, dias

salario = parseInt(prompt("Quanto você ganha"))
dias = parseInt(prompt("Quantos dias você trabalha"))

alert(salario/dias)