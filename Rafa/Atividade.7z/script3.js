let n1, n2, n3, n4

n1 = Number(prompt("fale a primeira nota"))
n2 = Number(prompt("fale a segunda nota"))
n3 = Number(prompt("fale a terceira nota"))
n4 = Number(prompt("fale a quarta nota"))

alert((n1+n2+n3+n4)/4) 