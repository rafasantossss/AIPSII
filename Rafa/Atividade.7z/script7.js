let dano, bonus

dano = Number(prompt("Qual foi o dano?"))

bonus = Number(prompt("Qual foi o bonus?"))

alert(dano*1.5+bonus)