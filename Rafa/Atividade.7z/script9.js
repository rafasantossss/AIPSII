let salario, moradia, agua, luz, internet, gasolina, netflix, telefone, outros

salario = Number(prompt("Quanto você ganha"))
moradia = Number(prompt("Quanto paga moradia?"))
agua = Number(prompt("Quanto paga de água"))
luz = Number(prompt("Quanto paga de luz?"))
internet = Number(prompt("quanto paga de internet?"))
gasolina = Number(prompt("Quanto gasta com gasolina"))
netflix = Number(prompt("Quanto custa a netflix?"))
telefone = Number(prompt("Quanto paga de telefone"))
outros = Number(prompt("Gasta mais algo? se sim coloque"))

alert(salario-(moradia, agua, luz, internet, gasolina, netflix, telefone, outros))
