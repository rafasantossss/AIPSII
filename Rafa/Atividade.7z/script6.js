let dano

dano = Number(prompt("Qual foi o dano?"))
alert(dano*1.5)