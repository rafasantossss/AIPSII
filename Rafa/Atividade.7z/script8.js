let n1, n2
let p1, p2, media

n1 = prompt("Nota 1: ")
n1 = Number(n1)

n2 = prompt("Nota 2: ")
n2 = Number(n2)

p1 = prompt("Prova 1: ")
p1 = Number(p1)

p2 = prompt("Prova 2: ")
p2 = Number(p2)

media = ((n1*p1 + n2*p2)/(p1+p2))
media = Number(media)

media = alert("Média poderada é: " + media)