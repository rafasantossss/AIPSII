let cafe, alunos, extra

cafe = parseInt(prompt("cafe"))
alunos = parseInt(prompt("alunos"))
extra = parseInt(prompt("extra"))

alert((cafe+extra)/alunos)