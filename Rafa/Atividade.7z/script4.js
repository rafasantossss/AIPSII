let vitorias, empates

vitorias = Number(prompt("Quantas vezes ganhou?"))
empates = Number(prompt("Quantos empates?"))

alert((vitorias*3) +empates)