let numero

numero = Number(prompt("Qual o numero da palestra que quer participar (1,2,3,4 ou 5): "))

if(numero == 1){
    alert("Animações com scrath, laboratorio 305, 19h")
}
if(numero == 2){
    alert("scrath para gamers, laboratorio 312, 20h")
}
if(numero == 3){
    alert("Javascript para leigos, laboratorio 101, 19h")
}
if(numero == 4){
    alert("Tópicos avançados, laboratorio 305, 20h")
}
if(numero == 5){
    alert("Vida e carreira, auditorio, 21h")
}