let A, B

A = Number(prompt("Primeiro numero: "))
B = Number(prompt("Segundo numero: "))

if(A>B){
    alert("O numero maior é: "+A)
}else{
    alert("O numero maior é: "+B)
}