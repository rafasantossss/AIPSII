let senha

senha = Number(prompt("Qual a senha?"))

if(senha == 1234){
    alert("Acesso permitido")
}else{
    alert("Acesso negado")
}