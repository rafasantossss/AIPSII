let placa

placa = Number(prompt("Ultimo digito da placa: "))

if(placa == 0){
    alert("Não pode rodar Segunda")
}
if(placa == 1){
    alert("Não pode rodar Segunda")
}
if(placa == 2){
    alert("Não pode rodar terça")
}
if(placa == 3){
    alert("Não pode rodar terça")
}
if(placa == 4){
    alert("Não pode rodar quarta")
}
if(placa == 5){
    alert("Não pode rodar quarta")
}
if(placa == 6){
    alert("Não pode rodar quinta")
}
if(placa == 7){
    alert("Não pode rodar quinta")
}
if(placa == 8){
    alert("Não pode rodar sexta")
}
if(placa == 9){
    alert("Não pode rodar sexta")
}