let idade

idade = Number(prompt("Digite sua idade: "))

if(idade >= 18){
alert("Você pode entrar :)")
}else{alert("Você não pode entrar :(")}

