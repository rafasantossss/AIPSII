let corrida1, corrida2, corrida3, corrida4, corrida5, resultado

corrida1 = Number(prompt("Quanto ganhou?"))
corrida2 = Number(prompt("Quanto ganhou?"))
corrida3 = Number(prompt("Quanto ganhou?"))
corrida4 = Number(prompt("Quanto ganhou?"))
corrida5 = Number(prompt("Quanto ganhou?"))

resultado = corrida1+corrida2+corrida3+corrida4+corrida5

alert(resultado)