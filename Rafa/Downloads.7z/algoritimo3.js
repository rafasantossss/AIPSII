let n, r 

n = Number(prompt("Qual o numero"))

r =  Math. sqrt(n)
alert(r)