let corrida1, corrida2, corrida3, corrida4, corrida5, descontado, resultado

corrida1 = Number(prompt("Quanto ganhou?"))
corrida2 = Number(prompt("Quanto ganhou?"))
corrida3 = Number(prompt("Quanto ganhou?"))
corrida4 = Number(prompt("Quanto ganhou?"))
corrida5 = Number(prompt("Quanto ganhou?"))

descontado = ((corrida1+corrida2+corrida3+corrida4+corrida5)*0.25)

resultado = ((corrida1+corrida2+corrida3+corrida4+corrida5)-descontado)

alert(resultado*20)