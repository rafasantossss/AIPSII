let area, base, altura 

base = Number(prompt("Qual a base"))
altura = Number(prompt("Qual a altura"))

alert((base*altura)/2)